const express = require('express');
const router = express.Router();
const Poll = require('../models/Poll');

// Create Poll
router.post('/', async (req, res) => {
  const { question, options } = req.body;
  const formattedOptions = options.map(opt => ({ text: opt, votes: 0 }));
  const poll = new Poll({ question, options: formattedOptions });
  await poll.save();
  res.status(201).json(poll);
});

// Get All Polls
router.get('/', async (req, res) => {
  const polls = await Poll.find();
  res.json(polls);
});

// Get Poll by ID
router.get('/:id', async (req, res) => {
  const poll = await Poll.findById(req.params.id);
  if (!poll) return res.status(404).json({ message: 'Poll not found' });
  res.json(poll);
});

// Vote on Option
router.post('/:id/vote', async (req, res) => {
  const { option } = req.body;
  const poll = await Poll.findById(req.params.id);
  if (!poll) return res.status(404).json({ message: 'Poll not found' });

  const selectedOption = poll.options.find(opt => opt.text === option);
  if (selectedOption) selectedOption.votes += 1;

  await poll.save();
  res.json(poll);
});

// Delete Poll
router.delete('/:id', async (req, res) => {
  try {
    await Poll.findByIdAndDelete(req.params.id);
    res.status(200).json({ message: 'Poll deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
