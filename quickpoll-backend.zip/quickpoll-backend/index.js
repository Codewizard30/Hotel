// const express = require('express');
// const mongoose = require('mongoose');
// const cors = require('cors');
// const pollRoutes = require('./routes/PollRoutes');  // New
// const authRoutes = require('./routes/authRoutes');  // New for login/signup

// const app = express();
// const PORT = 5000;

// app.use(cors());
// app.use(express.json());

// mongoose.connect('mongodb://localhost:27017/quickpoll', {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// }).then(() => console.log('MongoDB connected'))
//   .catch((err) => console.error(err));

// const pollSchema = new mongoose.Schema({
//   question: String,
//   options: [
//     {
//       text: String,
//       votes: { type: Number, default: 0 },
//     }
//   ],
// });

// const Poll = mongoose.model('Poll', pollSchema);

// // Routes
// app.use('/api/polls', pollRoutes);   // Handles poll CRUD
// app.use('/api/auth', authRoutes);    // Handles login/signup

// // Create Poll
// app.post('/api/polls', async (req, res) => {
//   const { question, options } = req.body;
//   const formattedOptions = options.map(opt => ({ text: opt, votes: 0 }));
//   const poll = new Poll({ question, options: formattedOptions });
//   await poll.save();
//   res.status(201).json(poll);
// });

// // Get All Polls
// app.get('/api/polls', async (req, res) => {
//   const polls = await Poll.find();
//   res.json(polls);
// });

// // Get Poll by ID
// app.get('/api/polls/:id', async (req, res) => {
//   const poll = await Poll.findById(req.params.id);
//   if (!poll) return res.status(404).json({ message: 'Poll not found' });
//   res.json(poll);
// });

// // Vote on Option
// app.post('/api/polls/:id/vote', async (req, res) => {
//   const { option } = req.body;
//   const poll = await Poll.findById(req.params.id);
//   if (!poll) return res.status(404).json({ message: 'Poll not found' });

//   const selectedOption = poll.options.find(opt => opt.text === option);
//   if (selectedOption) selectedOption.votes += 1;

//   await poll.save();
//   res.json(poll);
// });

// app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));

// // Delete Poll
// app.delete('/api/polls/:id', async (req, res) => {
//   try {
//     await Poll.findByIdAndDelete(req.params.id);
//     res.status(200).json({ message: 'Poll deleted successfully' });
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// });

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const pollRoutes = require('./routes/PollRoutes');  // Handles all /api/polls logic
const authRoutes = require('./routes/authRoutes');  // Handles login/signup

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/quickpoll', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log('MongoDB connected'))
  .catch((err) => console.error(err));

// Mount routes
app.use('/api/polls', pollRoutes);
app.use('/api/auth', authRoutes);

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
