import React from 'react';

export default function HotelCard({ hotel, onBook }) {
  return (
    <div className="hotel-card">
      <h2>{hotel.name}</h2>
      <p>{hotel.description}</p>
      <p><strong>${hotel.price}</strong> per night</p>
      <button onClick={() => onBook(hotel)}>Book Now</button>
    </div>
  );
}
