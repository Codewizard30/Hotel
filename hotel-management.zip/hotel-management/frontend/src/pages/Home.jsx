import React, { useEffect, useState } from 'react';
import HotelCard from '../components/HotelCard';
import axios from 'axios';

export default function Home() {
  const [hotels, setHotels] = useState([]);

  useEffect(() => {
    // Add unique _id for each hotel
    setHotels([
      { _id: "1", name: "Grand Palace", description: "5-star hotel near the beach", price: 250 },
      { _id: "2", name: "City Inn", description: "Affordable stay in downtown", price: 100 },
      { _id: "3", name: "Mountain Resort", description: "Relaxing escape in the hills", price: 180 },
    ]);
  }, []);

  // ✅ Replace this with the new function
  const handleBooking = async (hotel) => {
    const userName = prompt("Enter your name:");
    const userEmail = prompt("Enter your email:");

    if (!userName || !userEmail) {
      alert("Booking cancelled.");
      return;
    }

    try {
      await axios.post("http://localhost:5000/api/book", {
        hotelId: hotel._id,
        userName,
        userEmail,
      });
      alert("Booking successful!");
    } catch (error) {
      alert("Booking failed.");
      console.error(error);
    }
  };

  return (
    <div className="container">
      <div className="hotel-grid">
        {hotels.map((hotel, index) => (
          <HotelCard key={index} hotel={hotel} onBook={handleBooking} />
        ))}
      </div>
    </div>
  );
}
