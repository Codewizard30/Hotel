import React from 'react';

export default function Booking() {
  return (
    <div className="container">
      <h2>Booking Page</h2>
      <p>Booking functionality will go here.</p>
    </div>
  );
}
