// src/pages/AddHotel.jsx
import React, { useState } from 'react';
import axios from 'axios';

export default function AddHotel() {
  const [form, setForm] = useState({ name: '', description: '', price: '' });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/api/hotels", form);
      alert("Hotel added successfully!");
      setForm({ name: '', description: '', price: '' });
    } catch (err) {
      alert("Error adding hotel");
    }
  };

  return (
    <div className="container">
      <h2>Add New Hotel</h2>
      <form onSubmit={handleSubmit} style={{ maxWidth: "400px" }}>
        <input type="text" name="name" placeholder="Hotel Name" value={form.name} onChange={handleChange} required />
        <input type="text" name="description" placeholder="Description" value={form.description} onChange={handleChange} required />
        <input type="number" name="price" placeholder="Price" value={form.price} onChange={handleChange} required />
        <button type="submit">Add Hotel</button>
      </form>
    </div>
  );
}
