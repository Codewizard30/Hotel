import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api';
import { BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

export default function PollDetailsPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [poll, setPoll] = useState(null);
  const [selected, setSelected] = useState('');
  const [voted, setVoted] = useState(false);

  const fetchPoll = async () => {
    try {
      const res = await api.get(`/polls/${id}`);
      setPoll(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchPoll();
    const interval = setInterval(fetchPoll, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleVote = async () => {
    if (!selected) return;
    await api.post(`/polls/${id}/vote`, { option: selected });
    setVoted(true);
    fetchPoll();
  };

  const handleDelete = async () => {
    if (window.confirm("Are you sure you want to delete this poll?")) {
      await api.delete(`/polls/${id}`);
      navigate('/'); // Redirect to home page after deletion
    }
  };

  if (!poll) return <div>Loading...</div>;

  const chartData = poll.options.map(option => ({
    name: option.text,
    votes: option.votes,
  }));

  return (
    <div>
      <h2>{poll.question}</h2>

      {!voted && (
        <div>
          {poll.options.map((opt, i) => (
            <div key={i}>
              <label>
                <input
                  type="radio"
                  name="option"
                  value={opt.text}
                  onChange={(e) => setSelected(e.target.value)}
                />
                {opt.text}
              </label>
            </div>
          ))}
          <button onClick={handleVote}>Vote</button>
        </div>
      )}

      <h3>Live Results</h3>
      <BarChart width={400} height={300} data={chartData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis allowDecimals={false} />
        <Tooltip />
        <Bar dataKey="votes" fill="#8884d8" />
      </BarChart>

      <br />
      <button onClick={handleDelete} style={{ color: 'red' }}>
        Delete Poll
      </button>
    </div>
  );
}
