import React, { useState } from 'react';
import ReviewForm from './components/ReviewForm';
import ReviewList from './components/ReviewList';

function App() {
  const [reviews, setReviews] = useState([]);

  const addReview = (review) => {
    // Add a unique ID to each review
    const newReview = { ...review, id: Date.now() };
    setReviews([newReview, ...reviews]);
  };

  const deleteReview = (id) => {
    setReviews(reviews.filter((review) => review.id !== id));
  };

  return (
    <div className="app">
      <h1>🎬 Movie Reviews</h1>
      <ReviewForm onAddReview={addReview} />
      <ReviewList reviews={reviews} onDeleteReview={deleteReview} />
    </div>
  );
}

export default App;
