import React from 'react';

function ReviewCard({ title, comment, rating, onDelete }) {
  return (
    <div style={{
      background: '#2c2c2c',
      padding: '1rem',
      marginTop: '1rem',
      borderRadius: '8px',
      position: 'relative'
    }}>
      <h3 style={{ color: '#ffd700' }}>{title} ⭐{rating}</h3>
      <p>{comment}</p>
      <button
        onClick={onDelete}
        style={{
          marginTop: '0.5rem',
          backgroundColor: '#e74c3c',
          color: '#fff',
          border: 'none',
          padding: '0.5rem 1rem',
          borderRadius: '4px',
          cursor: 'pointer',
          fontSize: '0.9rem'
        }}
      >
        Delete
      </button>
    </div>
  );
}

export default ReviewCard;
